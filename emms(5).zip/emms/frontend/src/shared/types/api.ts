export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message: string | null;
  traceId: string;
}

export interface PaginatedResponse<T> {
  items: T[];
  totalCount: number;
  pageIndex: number;
  pageSize: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

export interface ApiError {
  message: string;
  errors?: Record<string, string[]>;
  traceId?: string;
  status: number;
}

export interface QueryParams {
  pageIndex?: number;
  pageSize?: number;
  sortColumn?: string;
  sortDirection?: 'asc' | 'desc';
  search?: string;
  filters?: Record<string, unknown>;
}
