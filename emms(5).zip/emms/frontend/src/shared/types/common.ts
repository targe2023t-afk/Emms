export type Nullable<T> = T | null;
export type Optional<T> = T | undefined;
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type WithId<T> = T & { id: string };

export interface SelectOption {
  label: string;
  value: string;
  disabled?: boolean;
}

export type Status = 'idle' | 'loading' | 'success' | 'error';
