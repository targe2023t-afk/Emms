/**
 * @component CheckboxGroup
 * @description Group of checkboxes with optional "Select All" functionality,
 *              vertical/horizontal layout, and disabled states.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <CheckboxGroup
 *   options={[
 *     { label: 'Email', value: 'email' },
 *     { label: 'SMS', value: 'sms' },
 *   ]}
 *   value={selected}
 *   onChange={setSelected}
 *   selectAll
 * />
 * ```
 */

import * as React from 'react';
import { Check } from 'lucide-react';
import { cn } from '@/shared/lib/utils/cn';

export interface CheckboxOption {
  /** Display label */
  label: string;
  /** Option value */
  value: string;
  /** Disabled state */
  disabled?: boolean;
}

export interface CheckboxGroupProps {
  /** Array of checkbox options */
  options: CheckboxOption[];
  /** Currently selected values */
  value: string[];
  /** Change handler */
  onChange: (values: string[]) => void;
  /** Layout direction */
  direction?: 'vertical' | 'horizontal';
  /** Show "Select All" option */
  selectAll?: boolean;
  /** "Select All" label text */
  selectAllLabel?: string;
  /** Additional CSS classes */
  className?: string;
}

export function CheckboxGroup({
  options,
  value,
  onChange,
  direction = 'vertical',
  selectAll = false,
  selectAllLabel = 'Select All',
  className,
}: CheckboxGroupProps) {
  const allValues = options.filter((o) => !o.disabled).map((o) => o.value);
  const allSelected = allValues.length > 0 && allValues.every((v) => value.includes(v));
  const someSelected = allValues.some((v) => value.includes(v)) && !allSelected;

  const toggleValue = (val: string) => {
    if (value.includes(val)) {
      onChange(value.filter((v) => v !== val));
    } else {
      onChange([...value, val]);
    }
  };

  const toggleAll = () => {
    if (allSelected) {
      onChange(value.filter((v) => !allValues.includes(v)));
    } else {
      onChange([...new Set([...value, ...allValues])]);
    }
  };

  return (
    <div className={cn('space-y-2', className)}>
      {selectAll && (
        <label className="flex items-center gap-2 cursor-pointer select-none">
          <div
            className={cn(
              'h-4 w-4 rounded border flex items-center justify-center transition-colors',
              allSelected
                ? 'bg-slate-900 border-slate-900'
                : someSelected
                ? 'bg-slate-900/50 border-slate-900'
                : 'border-slate-300 bg-white'
            )}
            onClick={toggleAll}
          >
            {(allSelected || someSelected) && (
              <Check className="h-3 w-3 text-white" strokeWidth={3} />
            )}
          </div>
          <span className="text-sm font-medium text-slate-900">{selectAllLabel}</span>
        </label>
      )}
      <div
        className={cn(
          'gap-3',
          direction === 'horizontal' ? 'flex flex-wrap' : 'flex flex-col'
        )}
      >
        {options.map((option) => {
          const isChecked = value.includes(option.value);
          return (
            <label
              key={option.value}
              className={cn(
                'flex items-center gap-2 cursor-pointer select-none',
                option.disabled && 'opacity-50 cursor-not-allowed'
              )}
            >
              <div
                className={cn(
                  'h-4 w-4 rounded border flex items-center justify-center transition-colors',
                  isChecked
                    ? 'bg-slate-900 border-slate-900'
                    : 'border-slate-300 bg-white hover:border-slate-400'
                )}
                onClick={() => !option.disabled && toggleValue(option.value)}
              >
                {isChecked && <Check className="h-3 w-3 text-white" strokeWidth={3} />}
              </div>
              <span className="text-sm text-slate-700">{option.label}</span>
            </label>
          );
        })}
      </div>
    </div>
  );
}
