/**
 * @component FormField
 * @description Wrapper component for form inputs providing consistent label,
 *              error message, help text, and required indicator styling.
 *              Integrates with React Hook Form via register prop.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <FormField label="Email" error={errors.email?.message} required>
 *   <Input {...register('email')} />
 * </FormField>
 * ```
 */

import * as React from 'react';
import { cn } from '@/shared/lib/utils/cn';

export interface FormFieldProps {
  /** Field label text */
  label?: string;
  /** Error message to display */
  error?: string;
  /** Help text or description */
  helpText?: string;
  /** Mark field as required */
  required?: boolean;
  /** Field ID for label association */
  id?: string;
  /** Additional CSS classes */
  className?: string;
  /** Child input element */
  children: React.ReactNode;
}

export const FormField = React.forwardRef<HTMLDivElement, FormFieldProps>(
  ({ label, error, helpText, required, id, className, children }, ref) => {
    return (
      <div ref={ref} className={cn('space-y-1.5', className)}>
        {label && (
          <label
            htmlFor={id}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
            {required && <span className="text-rose-500 ml-0.5">*</span>}
          </label>
        )}
        {children}
        {error && (
          <p className="text-xs text-rose-600 font-medium" role="alert">{error}</p>
        )}
        {helpText && !error && (
          <p className="text-xs text-slate-500">{helpText}</p>
        )}
      </div>
    );
  }
);
FormField.displayName = 'FormField';
