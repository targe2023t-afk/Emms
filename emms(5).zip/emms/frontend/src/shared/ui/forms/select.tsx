/**
 * @component Select
 * @description Accessible select dropdown with support for grouped options,
 *              search filtering, disabled states, and custom rendering.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <Select
 *   options={[
 *     { label: 'Active', value: 'active' },
 *     { label: 'Inactive', value: 'inactive', disabled: true },
 *   ]}
 *   value={status}
 *   onChange={(val) => setStatus(val)}
 * />
 * ```
 */

import * as React from 'react';
import { ChevronDown } from 'lucide-react';
import { cn } from '@/shared/lib/utils/cn';

export interface SelectOption {
  /** Display label */
  label: string;
  /** Option value */
  value: string;
  /** Disabled state */
  disabled?: boolean;
  /** Group name for categorization */
  group?: string;
}

export interface SelectProps {
  /** Array of options */
  options: SelectOption[];
  /** Currently selected value */
  value?: string;
  /** Change handler */
  onChange?: (value: string) => void;
  /** Placeholder text when no selection */
  placeholder?: string;
  /** Disabled state */
  disabled?: boolean;
  /** Error state styling */
  error?: boolean;
  /** Size variant */
  size?: 'sm' | 'md' | 'lg';
  /** Additional CSS classes */
  className?: string;
  /** Accessible label */
  ariaLabel?: string;
}

const sizeMap = {
  sm: 'h-8 text-xs px-2.5',
  md: 'h-9 text-sm px-3',
  lg: 'h-10 text-sm px-4',
};

export function Select({
  options,
  value,
  onChange,
  placeholder = 'Select an option...',
  disabled,
  error,
  size = 'md',
  className,
  ariaLabel,
}: SelectProps) {
  const selectedOption = options.find((o) => o.value === value);

  // Group options
  const groups = React.useMemo(() => {
    const map = new Map<string, SelectOption[]>();
    options.forEach((opt) => {
      const group = opt.group || '';
      if (!map.has(group)) map.set(group, []);
      map.get(group)!.push(opt);
    });
    return map;
  }, [options]);

  return (
    <div className={cn('relative', className)}>
      <select
        value={value || ''}
        onChange={(e) => onChange?.(e.target.value)}
        disabled={disabled}
        aria-label={ariaLabel}
        className={cn(
          'w-full appearance-none rounded-lg border bg-white pr-8',
          'focus:ring-2 focus:ring-slate-900 focus:outline-none transition-all',
          sizeMap[size],
          error
            ? 'border-rose-300 focus:ring-rose-500'
            : 'border-slate-200 focus:border-slate-900',
          disabled && 'opacity-50 cursor-not-allowed bg-slate-50'
        )}
      >
        <option value="" disabled>
          {placeholder}
        </option>
        {Array.from(groups.entries()).map(([groupName, groupOptions]) => (
          <React.Fragment key={groupName}>
            {groupName && (
              <optgroup label={groupName}>
                {groupOptions.map((opt) => (
                  <option key={opt.value} value={opt.value} disabled={opt.disabled}>
                    {opt.label}
                  </option>
                ))}
              </optgroup>
            )}
            {!groupName &&
              groupOptions.map((opt) => (
                <option key={opt.value} value={opt.value} disabled={opt.disabled}>
                  {opt.label}
                </option>
              ))}
          </React.Fragment>
        ))}
      </select>
      <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
    </div>
  );
}
