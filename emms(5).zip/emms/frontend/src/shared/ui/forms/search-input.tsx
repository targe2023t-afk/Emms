/**
 * @component SearchInput
 * @description Search input with built-in debounce, clear button, and
 *              loading state. Emits search events after typing pauses.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <SearchInput
 *   placeholder="Search assets..."
 *   debounceMs={300}
 *   onSearch={(query) => setSearch(query)}
 *   loading={isSearching}
 * />
 * ```
 */

import * as React from 'react';
import { Search, X } from 'lucide-react';
import { cn } from '@/shared/lib/utils/cn';

export interface SearchInputProps {
  /** Placeholder text */
  placeholder?: string;
  /** Debounce delay in milliseconds */
  debounceMs?: number;
  /** Callback fired after debounce */
  onSearch?: (query: string) => void;
  /** Controlled value */
  value?: string;
  /** Loading state indicator */
  loading?: boolean;
  /** Additional CSS classes */
  className?: string;
  /** Input disabled state */
  disabled?: boolean;
}

export function SearchInput({
  placeholder = 'Search...',
  debounceMs = 300,
  onSearch,
  value,
  loading,
  className,
  disabled,
}: SearchInputProps) {
  const [internalValue, setInternalValue] = React.useState(value || '');
  const timeoutRef = React.useRef<ReturnType<typeof setTimeout>>();

  const currentValue = value !== undefined ? value : internalValue;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    if (value === undefined) setInternalValue(newValue);
    onSearch?.(newValue);

    clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      onSearch?.(newValue);
    }, debounceMs);
  };

  const handleClear = () => {
    if (value === undefined) setInternalValue('');
    onSearch?.('');
  };

  React.useEffect(() => () => clearTimeout(timeoutRef.current), []);

  return (
    <div className={cn('relative', className)}>
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
      <input
        type="search"
        value={currentValue}
        onChange={handleChange}
        placeholder={placeholder}
        disabled={disabled}
        className={cn(
          'w-full h-9 pl-9 pr-9 rounded-lg bg-slate-100 border-0 text-sm',
          'focus:ring-2 focus:ring-slate-900 focus:outline-none transition-all',
          'placeholder:text-slate-400',
          disabled && 'opacity-50 cursor-not-allowed'
        )}
      />
      {currentValue && (
        <button
          type="button"
          onClick={handleClear}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
        >
          <X className="h-4 w-4" />
        </button>
      )}
      {loading && (
        <div className="absolute right-3 top-1/2 -translate-y-1/2">
          <div className="h-4 w-4 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" />
        </div>
      )}
    </div>
  );
}
