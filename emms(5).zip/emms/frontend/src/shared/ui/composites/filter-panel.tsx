/**
 * @component FilterPanel
 * @description Reusable filter panel supporting search, select, date range,
 *              checkbox groups, and quick filters. Integrates with URL state.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <FilterPanel
 *   filters={[
 *     { type: 'search', key: 'query', label: 'Search', placeholder: 'Search...' },
 *     { type: 'select', key: 'status', label: 'Status', options: [...] },
 *   ]}
 *   onFilterChange={(filters) => setFilters(filters)}
 * />
 * ```
 */

import * as React from 'react';
import { X, Filter } from 'lucide-react';
import { cn } from '@/shared/lib/utils/cn';
import { Button } from '@/shared/ui/primitives/button';
import { SearchInput } from '@/shared/ui/forms/search-input';
import { Select, type SelectOption } from '@/shared/ui/forms/select';
import { CheckboxGroup, type CheckboxOption } from '@/shared/ui/forms/checkbox-group';

export type FilterType = 'search' | 'select' | 'checkbox' | 'date-range' | 'quick';

export interface FilterConfig {
  /** Filter type */
  type: FilterType;
  /** Unique filter key */
  key: string;
  /** Filter label */
  label: string;
  /** Placeholder text (for search) */
  placeholder?: string;
  /** Options (for select/checkbox) */
  options?: SelectOption[] | CheckboxOption[];
  /** Quick filter presets */
  presets?: { label: string; value: Record<string, any> }[];
}

export interface FilterPanelProps {
  /** Filter configurations */
  filters: FilterConfig[];
  /** Current filter values */
  values?: Record<string, any>;
  /** Filter change handler */
  onFilterChange: (values: Record<string, any>) => void;
  /** Additional CSS classes */
  className?: string;
  /** Collapsible variant */
  collapsible?: boolean;
  /** Default collapsed state */
  defaultCollapsed?: boolean;
}

export function FilterPanel({
  filters,
  values = {},
  onFilterChange,
  className,
  collapsible = false,
  defaultCollapsed = false,
}: FilterPanelProps) {
  const [collapsed, setCollapsed] = React.useState(defaultCollapsed);
  const [localValues, setLocalValues] = React.useState(values);

  const updateValue = (key: string, value: any) => {
    const newValues = { ...localValues, [key]: value };
    setLocalValues(newValues);
    onFilterChange(newValues);
  };

  const clearFilters = () => {
    setLocalValues({});
    onFilterChange({});
  };

  const hasActiveFilters = Object.keys(localValues).some((k) => {
    const v = localValues[k];
    return v !== undefined && v !== '' && v !== null && (Array.isArray(v) ? v.length > 0 : true);
  });

  const panelContent = (
    <div className="space-y-4">
      {filters.map((filter) => (
        <div key={filter.key}>
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2 block">
            {filter.label}
          </label>
          {filter.type === 'search' && (
            <SearchInput
              placeholder={filter.placeholder || `Search ${filter.label}...`}
              value={localValues[filter.key] || ''}
              onSearch={(val) => updateValue(filter.key, val)}
            />
          )}
          {filter.type === 'select' && filter.options && (
            <Select
              options={filter.options as SelectOption[]}
              value={localValues[filter.key] || ''}
              onChange={(val) => updateValue(filter.key, val)}
              placeholder={`Select ${filter.label}`}
            />
          )}
          {filter.type === 'checkbox' && filter.options && (
            <CheckboxGroup
              options={filter.options as CheckboxOption[]}
              value={localValues[filter.key] || []}
              onChange={(val) => updateValue(filter.key, val)}
            />
          )}
          {filter.type === 'quick' && filter.presets && (
            <div className="flex flex-wrap gap-2">
              {filter.presets.map((preset) => (
                <button
                  key={preset.label}
                  onClick={() => {
                    setLocalValues(preset.value);
                    onFilterChange(preset.value);
                  }}
                  className={cn(
                    'rounded-full px-3 py-1 text-xs font-medium transition-colors',
                    JSON.stringify(localValues) === JSON.stringify(preset.value)
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  )}
                >
                  {preset.label}
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
      {hasActiveFilters && (
        <Button variant="ghost" size="sm" className="w-full text-rose-600 hover:text-rose-700" onClick={clearFilters}>
          <X className="h-4 w-4 mr-1" />
          Clear all filters
        </Button>
      )}
    </div>
  );

  if (collapsible) {
    return (
      <div className={cn('border border-slate-200 rounded-lg bg-white', className)}>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center justify-between w-full px-4 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
        >
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filters
            {hasActiveFilters && (
              <span className="rounded-full bg-slate-900 text-white px-1.5 py-0.5 text-[10px] font-bold">
                {Object.keys(localValues).filter((k) => localValues[k]).length}
              </span>
            )}
          </div>
          <span className="text-slate-400">{collapsed ? '▶' : '▼'}</span>
        </button>
        {!collapsed && <div className="px-4 pb-4 border-t border-slate-100 pt-4">{panelContent}</div>}
      </div>
    );
  }

  return (
    <div className={cn('border border-slate-200 rounded-lg bg-white p-4', className)}>
      {panelContent}
    </div>
  );
}
