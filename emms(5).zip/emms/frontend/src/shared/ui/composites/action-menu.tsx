/**
 * @component ActionMenu
 * @description Dropdown action menu for table rows, cards, and list items.
 *              Supports grouped actions, disabled states, and confirmation dialogs.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <ActionMenu
 *   actions={[
 *     { label: 'View', icon: Eye, onClick: () => navigate('/view') },
 *     { label: 'Edit', icon: Pencil, onClick: () => navigate('/edit') },
 *     { type: 'divider' },
 *     { label: 'Delete', icon: Trash2, variant: 'destructive', onClick: handleDelete, confirm: true },
 *   ]}
 * />
 * ```
 */

import * as React from 'react';
import { MoreHorizontal } from 'lucide-react';
import { cn } from '@/shared/lib/utils/cn';
import { Button } from '@/shared/ui/primitives/button';
import type { LucideIcon } from 'lucide-react';

export type ActionVariant = 'default' | 'destructive';

export interface ActionItem {
  /** Action label */
  label: string;
  /** Icon component */
  icon?: LucideIcon;
  /** Click handler */
  onClick?: () => void;
  /** Visual variant */
  variant?: ActionVariant;
  /** Disabled state */
  disabled?: boolean;
  /** Show confirmation dialog */
  confirm?: boolean;
  /** Confirmation message */
  confirmMessage?: string;
  /** Divider instead of action */
  type?: 'action' | 'divider';
}

export interface ActionMenuProps {
  /** Array of actions */
  actions: ActionItem[];
  /** Button size */
  size?: 'sm' | 'md';
  /** Additional CSS classes */
  className?: string;
  /** Alignment of dropdown */
  align?: 'left' | 'right';
}

export function ActionMenu({
  actions,
  size = 'sm',
  className,
  align = 'right',
}: ActionMenuProps) {
  const [isOpen, setIsOpen] = React.useState(false);
  const menuRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleAction = (action: ActionItem) => {
    if (action.disabled) return;
    if (action.confirm) {
      if (window.confirm(action.confirmMessage || `Are you sure you want to ${action.label.toLowerCase()}?`)) {
        action.onClick?.();
      }
    } else {
      action.onClick?.();
    }
    setIsOpen(false);
  };

  return (
    <div ref={menuRef} className={cn('relative inline-block', className)}>
      <Button
        variant="ghost"
        size={size === 'sm' ? 'icon' : 'default'}
        className="h-8 w-8"
        onClick={() => setIsOpen(!isOpen)}
      >
        <MoreHorizontal className="h-4 w-4" />
      </Button>

      {isOpen && (
        <div
          className={cn(
            'absolute z-50 min-w-[10rem] rounded-lg border border-slate-200 bg-white shadow-lg py-1',
            align === 'right' ? 'right-0' : 'left-0',
            'mt-1'
          )}
        >
          {actions.map((action, index) => {
            if (action.type === 'divider') {
              return <div key={`divider-${index}`} className="my-1 h-px bg-slate-100" />;
            }

            const Icon = action.icon;
            return (
              <button
                key={action.label}
                onClick={() => handleAction(action)}
                disabled={action.disabled}
                className={cn(
                  'flex w-full items-center gap-2 px-3 py-2 text-sm transition-colors',
                  action.variant === 'destructive'
                    ? 'text-rose-600 hover:bg-rose-50'
                    : 'text-slate-700 hover:bg-slate-50',
                  action.disabled && 'opacity-50 cursor-not-allowed'
                )}
              >
                {Icon && <Icon className="h-4 w-4" />}
                {action.label}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
