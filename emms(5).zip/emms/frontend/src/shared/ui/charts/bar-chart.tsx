/**
 * @component BarChart
 * @description SVG-based bar chart with zero external dependencies. Supports
 *              horizontal/vertical orientation, grouped/stacked bars, and tooltips.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <BarChart
 *   data={[
 *     { label: 'Jan', values: [30, 20] },
 *     { label: 'Feb', values: [45, 35] },
 *   ]}
 *   series={['Completed', 'Pending']}
 *   colors={['#10b981', '#f59e0b']}
 * />
 * ```
 */

import * as React from 'react';
import { cn } from '@/shared/lib/utils/cn';

export interface BarChartDataPoint {
  /** X-axis label */
  label: string;
  /** Values for each series */
  values: number[];
}

export interface BarChartProps {
  /** Data points */
  data: BarChartDataPoint[];
  /** Series names */
  series: string[];
  /** Colors for each series */
  colors?: string[];
  /** Chart height */
  height?: number;
  /** Show values on bars */
  showValues?: boolean;
  /** Stacked bars */
  stacked?: boolean;
  /** Horizontal orientation */
  horizontal?: boolean;
  /** Additional CSS classes */
  className?: string;
  /** Bar click handler */
  onBarClick?: (dataPoint: BarChartDataPoint, seriesIndex: number) => void;
}

const defaultColors = ['#10b981', '#0ea5e9', '#f59e0b', '#f43f5e', '#8b5cf6', '#64748b'];

export function BarChart({
  data,
  series,
  colors = defaultColors,
  height = 200,
  showValues = false,
  stacked = false,
  horizontal = false,
  className,
  onBarClick,
}: BarChartProps) {
  const [hoveredBar, setHoveredBar] = React.useState<{ dataIndex: number; seriesIndex: number } | null>(null);

  const maxValue = stacked
    ? Math.max(...data.map((d) => d.values.reduce((a, b) => a + b, 0)))
    : Math.max(...data.flatMap((d) => d.values), 0);

  const safeMax = maxValue || 1;
  const barCount = data.length;
  const seriesCount = series.length;

  // SVG dimensions
  const padding = { top: 10, right: 10, bottom: 30, left: 40 };
  const chartWidth = 600;
  const chartHeight = height;
  const drawWidth = chartWidth - padding.left - padding.right;
  const drawHeight = chartHeight - padding.top - padding.bottom;

  const barWidth = stacked
    ? (drawWidth / barCount) * 0.6
    : (drawWidth / barCount) * 0.6 / seriesCount;

  const groupWidth = (drawWidth / barCount) * 0.6;
  const groupSpacing = drawWidth / barCount;

  return (
    <div className={cn('w-full', className)}>
      <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-auto" preserveAspectRatio="xMidYMid meet">
        {/* Y-axis grid lines */}
        {Array.from({ length: 5 }).map((_, i) => {
          const y = padding.top + (drawHeight / 4) * i;
          const value = Math.round(safeMax - (safeMax / 4) * i);
          return (
            <g key={`grid-${i}`}>
              <line
                x1={padding.left}
                y1={y}
                x2={chartWidth - padding.right}
                y2={y}
                stroke="#e2e8f0"
                strokeWidth="1"
                strokeDasharray={i === 4 ? undefined : '4,4'}
              />
              <text x={padding.left - 5} y={y + 4} textAnchor="end" fontSize="10" fill="#94a3b8">
                {value}
              </text>
            </g>
          );
        })}

        {/* Bars */}
        {data.map((dataPoint, dataIndex) => {
          const groupX = padding.left + dataIndex * groupSpacing + (groupSpacing - groupWidth) / 2;

          if (stacked) {
            let currentY = padding.top + drawHeight;
            return (
              <g key={dataPoint.label}>
                {dataPoint.values.map((value, seriesIndex) => {
                  const barHeight = (value / safeMax) * drawHeight;
                  const y = currentY - barHeight;
                  currentY = y;
                  const color = colors[seriesIndex % colors.length];

                  return (
                    <rect
                      key={seriesIndex}
                      x={groupX}
                      y={y}
                      width={groupWidth}
                      height={barHeight}
                      fill={color}
                      rx={2}
                      className="transition-all duration-300 hover:opacity-80 cursor-pointer"
                      onMouseEnter={() => setHoveredBar({ dataIndex, seriesIndex })}
                      onMouseLeave={() => setHoveredBar(null)}
                      onClick={() => onBarClick?.(dataPoint, seriesIndex)}
                    />
                  );
                })}
              </g>
            );
          }

          return (
            <g key={dataPoint.label}>
              {dataPoint.values.map((value, seriesIndex) => {
                const barHeight = (value / safeMax) * drawHeight;
                const x = groupX + seriesIndex * barWidth;
                const y = padding.top + drawHeight - barHeight;
                const color = colors[seriesIndex % colors.length];

                return (
                  <rect
                    key={seriesIndex}
                    x={x}
                    y={y}
                    width={barWidth - 2}
                    height={barHeight}
                    fill={color}
                    rx={2}
                    className="transition-all duration-300 hover:opacity-80 cursor-pointer"
                    onMouseEnter={() => setHoveredBar({ dataIndex, seriesIndex })}
                    onMouseLeave={() => setHoveredBar(null)}
                    onClick={() => onBarClick?.(dataPoint, seriesIndex)}
                  />
                );
              })}
            </g>
          );
        })}

        {/* X-axis labels */}
        {data.map((dataPoint, index) => {
          const x = padding.left + index * groupSpacing + groupSpacing / 2;
          return (
            <text
              key={dataPoint.label}
              x={x}
              y={chartHeight - 5}
              textAnchor="middle"
              fontSize="10"
              fill="#64748b"
            >
              {dataPoint.label}
            </text>
          );
        })}
      </svg>

      {/* Legend */}
      <div className="flex items-center justify-center gap-4 mt-3">
        {series.map((s, i) => (
          <div key={s} className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: colors[i % colors.length] }} />
            <span className="text-xs text-slate-600">{s}</span>
          </div>
        ))}
      </div>

      {/* Tooltip */}
      {hoveredBar && (
        <div className="absolute bg-slate-900 text-white text-xs rounded px-2 py-1 pointer-events-none">
          {series[hoveredBar.seriesIndex]}: {data[hoveredBar.dataIndex].values[hoveredBar.seriesIndex]}
        </div>
      )}
    </div>
  );
}
