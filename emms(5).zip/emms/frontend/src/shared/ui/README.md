# EMMS Shared UI Component Library

Enterprise-grade reusable UI components for the EMMS (Enterprise Maintenance Management System).

## Design Principles

| Principle | Implementation |
|-----------|---------------|
| **Single Responsibility** | Each component does one thing and does it well |
| **Open/Closed** | Components are open for extension via props, closed for modification |
| **Liskov Substitution** | All variants of a component type are interchangeable |
| **Interface Segregation** | Props are granular; consumers only depend on what they use |
| **Dependency Inversion** | Components depend on abstractions (types/interfaces), not concretions |

## Component Architecture

```
shared/ui/
├── primitives/          # Atomic components (shadcn/ui base)
│   ├── button.tsx
│   ├── input.tsx
│   ├── card.tsx
│   └── ...
├── data-display/        # Data presentation components
│   ├── stat-card.tsx    # KPI cards with trends
│   ├── badge-list.tsx   # Status/tag lists
│   ├── empty-state.tsx  # Empty state placeholders
│   └── timeline.tsx     # Event timelines
├── feedback/            # User feedback components
│   ├── alert.tsx        # Alert banners
│   ├── progress-bar.tsx # Progress indicators
│   ├── loading-overlay.tsx # Loading states
│   └── status-indicator.tsx # Status dots
├── forms/               # Form input components
│   ├── form-field.tsx   # Field wrapper with error/help
│   ├── search-input.tsx # Debounced search
│   ├── select.tsx       # Dropdown select
│   └── checkbox-group.tsx # Checkbox groups
├── navigation/           # Navigation components
│   ├── breadcrumbs.tsx  # Path breadcrumbs
│   ├── tabs.tsx         # Tab navigation
│   └── pagination.tsx   # Pagination controls
├── overlays/            # Modal overlays
│   ├── modal.tsx        # Dialog modals
│   ├── drawer.tsx       # Slide panels
│   └── tooltip.tsx      # Hover tooltips
├── layout/              # Layout components
│   ├── page-header.tsx  # Page headers
│   ├── split-pane.tsx   # Resizable panes
│   └── scroll-container.tsx # Scroll wrappers
├── tables/              # Table components
│   └── data-table.tsx   # Generic data table
├── charts/              # Chart components
│   └── bar-chart.tsx    # SVG bar charts
└── composites/          # Complex composite components
    ├── filter-panel.tsx # Filter panels
    └── action-menu.tsx  # Action dropdowns
```

## Usage Examples

### StatCard
```tsx
import { StatCard } from '@/shared/ui';

<StatCard
  label="Total Revenue"
  value="$284,520"
  change="+8.4%"
  trend="up"
  icon={DollarSign}
  color="emerald"
  sparklineData={[30, 45, 38, 52, 48, 60, 55, 70]}
/>
```

### DataTable
```tsx
import { DataTable } from '@/shared/ui';

<DataTable
  data={workOrders}
  columns={[
    { key: 'number', header: 'WO #', sortable: true },
    { key: 'asset', header: 'Asset', render: (row) => <span>{row.asset}</span> },
    { key: 'status', header: 'Status', render: (row) => <StatusBadge status={row.status} /> },
  ]}
  selectable
  onRowClick={(row) => navigate(`/wo/${row.id}`)}
/>
```

### Modal
```tsx
import { Modal, ModalBody, ModalFooter } from '@/shared/ui';

<Modal isOpen={isOpen} onClose={() => setIsOpen(false)} title="Confirm">
  <ModalBody>Are you sure?</ModalBody>
  <ModalFooter>
    <Button variant="outline" onClick={() => setIsOpen(false)}>Cancel</Button>
    <Button onClick={handleConfirm}>Confirm</Button>
  </ModalFooter>
</Modal>
```

## Type Exports

All component props are exported for TypeScript consumers:

```tsx
import type { StatCardProps, DataTableProps, ModalProps } from '@/shared/ui';
```

## Accessibility

- All interactive components support keyboard navigation
- ARIA roles and attributes are properly applied
- Focus management in Modals and Drawers
- Color contrast meets WCAG 2.1 AA standards

## Styling

Components use Tailwind CSS with the EMMS design tokens:
- Colors: `slate`, `emerald`, `sky`, `amber`, `rose`, `violet`
- Spacing: Consistent 4px grid system
- Typography: Inter font family
- Shadows: Subtle elevation system
