/**
 * @component SplitPane
 * @description Resizable two-pane layout with draggable divider. Supports
 *              horizontal and vertical orientations with min/max constraints.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <SplitPane
 *   left={<Sidebar />}
 *   right={<MainContent />}
 *   defaultSplit={30}
 *   minLeft={20}
 *   maxLeft={50}
 * />
 * ```
 */

import * as React from 'react';
import { cn } from '@/shared/lib/utils/cn';

export type SplitOrientation = 'horizontal' | 'vertical';

export interface SplitPaneProps {
  /** Left/Top pane content */
  first: React.ReactNode;
  /** Right/Bottom pane content */
  second: React.ReactNode;
  /** Orientation */
  orientation?: SplitOrientation;
  /** Default split percentage (0-100) */
  defaultSplit?: number;
  /** Minimum first pane percentage */
  minFirst?: number;
  /** Maximum first pane percentage */
  maxFirst?: number;
  /** Additional CSS classes */
  className?: string;
  /** First pane className */
  firstClassName?: string;
  /** Second pane className */
  secondClassName?: string;
}

export function SplitPane({
  first,
  second,
  orientation = 'horizontal',
  defaultSplit = 50,
  minFirst = 20,
  maxFirst = 80,
  className,
  firstClassName,
  secondClassName,
}: SplitPaneProps) {
  const [split, setSplit] = React.useState(defaultSplit);
  const [isDragging, setIsDragging] = React.useState(false);
  const containerRef = React.useRef<HTMLDivElement>(null);

  const isHorizontal = orientation === 'horizontal';

  const handleMouseDown = () => setIsDragging(true);

  React.useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const total = isHorizontal ? rect.width : rect.height;
      const offset = isHorizontal ? e.clientX - rect.left : e.clientY - rect.top;
      const percentage = (offset / total) * 100;
      setSplit(Math.max(minFirst, Math.min(maxFirst, percentage)));
    };

    const handleMouseUp = () => setIsDragging(false);

    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, isHorizontal, minFirst, maxFirst]);

  const dividerCursor = isHorizontal ? 'cursor-col-resize' : 'cursor-row-resize';

  return (
    <div
      ref={containerRef}
      className={cn(
        'flex overflow-hidden',
        isHorizontal ? 'flex-row' : 'flex-col',
        className
      )}
    >
      <div
        className={cn('overflow-auto', firstClassName)}
        style={{
          [isHorizontal ? 'width' : 'height']: `${split}%`,
          [isHorizontal ? 'minWidth' : 'minHeight']: `${minFirst}%`,
        }}
      >
        {first}
      </div>
      <div
        className={cn(
          'bg-slate-200 hover:bg-slate-300 transition-colors shrink-0',
          isHorizontal ? 'w-1 cursor-col-resize' : 'h-1 cursor-row-resize',
          isDragging && 'bg-slate-400'
        )}
        onMouseDown={handleMouseDown}
      />
      <div
        className={cn('flex-1 overflow-auto', secondClassName)}
        style={{
          [isHorizontal ? 'minWidth' : 'minHeight']: `${100 - maxFirst}%`,
        }}
      >
        {second}
      </div>
    </div>
  );
}
