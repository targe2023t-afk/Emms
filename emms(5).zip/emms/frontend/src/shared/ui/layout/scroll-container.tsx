/**
 * @component ScrollContainer
 * @description Scrollable container with optional top/bottom fade shadows,
 *              custom scrollbar styling, and max height constraints.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <ScrollContainer maxHeight="400px" showShadows>
 *   {longList.map(item => <Item key={item.id} {...item} />)}
 * </ScrollContainer>
 * ```
 */

import * as React from 'react';
import { cn } from '@/shared/lib/utils/cn';

export interface ScrollContainerProps {
  /** Maximum height before scrolling */
  maxHeight?: string | number;
  /** Show gradient shadows at edges */
  showShadows?: boolean;
  /** Hide scrollbar visually */
  hideScrollbar?: boolean;
  /** Horizontal scrolling */
  horizontal?: boolean;
  /** Additional CSS classes */
  className?: string;
  /** Child content */
  children: React.ReactNode;
}

export function ScrollContainer({
  maxHeight,
  showShadows = false,
  hideScrollbar = false,
  horizontal = false,
  className,
  children,
}: ScrollContainerProps) {
  const maxHeightStyle = typeof maxHeight === 'number' ? `${maxHeight}px` : maxHeight;

  return (
    <div className={cn('relative', className)}>
      {showShadows && (
        <>
          <div className="absolute top-0 left-0 right-0 h-4 bg-gradient-to-b from-white to-transparent z-10 pointer-events-none" />
          <div className="absolute bottom-0 left-0 right-0 h-4 bg-gradient-to-t from-white to-transparent z-10 pointer-events-none" />
        </>
      )}
      <div
        className={cn(
          'overflow-auto',
          horizontal ? 'overflow-x-auto overflow-y-hidden' : 'overflow-y-auto overflow-x-hidden',
          hideScrollbar && 'scrollbar-hide',
          showShadows && 'py-4'
        )}
        style={{ maxHeight: maxHeightStyle }}
      >
        {children}
      </div>
    </div>
  );
}
