/**
 * @component PageHeader
 * @description Consistent page header with title, description, breadcrumbs,
 *              and action buttons. Adapts to mobile with responsive layout.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <PageHeader
 *   title="Work Orders"
 *   description="Manage and track all maintenance work orders"
 *   breadcrumbs={[{ label: 'Home', href: '/' }, { label: 'Work Orders' }]}
 *   actions={[
 *     { label: 'Export', variant: 'outline', onClick: handleExport },
 *     { label: 'New WO', variant: 'default', onClick: handleCreate },
 *   ]}
 * />
 * ```
 */

import { cn } from '@/shared/lib/utils/cn';
import { Button } from '@/shared/ui/primitives/button';
import { Breadcrumbs, type BreadcrumbItem } from '@/shared/ui/navigation/breadcrumbs';

export interface PageHeaderAction {
  /** Button label */
  label: string;
  /** Button variant */
  variant?: 'default' | 'outline' | 'ghost' | 'destructive';
  /** Click handler */
  onClick: () => void;
  /** Icon component */
  icon?: React.ComponentType<{ className?: string }>;
  /** Disabled state */
  disabled?: boolean;
}

export interface PageHeaderProps {
  /** Page title */
  title: string;
  /** Page description */
  description?: string;
  /** Breadcrumb items */
  breadcrumbs?: BreadcrumbItem[];
  /** Action buttons */
  actions?: PageHeaderAction[];
  /** Additional CSS classes */
  className?: string;
}

export function PageHeader({
  title,
  description,
  breadcrumbs,
  actions,
  className,
}: PageHeaderProps) {
  return (
    <div className={cn('mb-6', className)}>
      {breadcrumbs && (
        <div className="mb-3">
          <Breadcrumbs items={breadcrumbs} />
        </div>
      )}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">{title}</h1>
          {description && <p className="text-sm text-slate-500 mt-0.5">{description}</p>}
        </div>
        {actions && actions.length > 0 && (
          <div className="flex items-center gap-2">
            {actions.map((action, i) => {
              const Icon = action.icon;
              return (
                <Button
                  key={i}
                  variant={action.variant || 'default'}
                  size="sm"
                  disabled={action.disabled}
                  onClick={action.onClick}
                  className="gap-1.5"
                >
                  {Icon && <Icon className="h-4 w-4" />}
                  {action.label}
                </Button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
