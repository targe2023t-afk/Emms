/**
 * @component BadgeList
 * @description Renders a list of items as color-coded badges. Supports multiple
 *              color schemes and sizes. Ideal for status lists, category tags,
 *              and filter chips.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <BadgeList
 *   items={[
 *     { label: 'Active', value: 'active', color: 'emerald' },
 *     { label: 'Pending', value: 'pending', color: 'amber' },
 *   ]}
 *   onItemClick={(item) => console.log(item.value)}
 * />
 * ```
 */

import { cn } from '@/shared/lib/utils/cn';

export type BadgeColor = 'emerald' | 'sky' | 'amber' | 'rose' | 'violet' | 'slate' | 'primary';

export interface BadgeListItem {
  /** Display text */
  label: string;
  /** Unique identifier */
  value: string;
  /** Color scheme */
  color: BadgeColor;
  /** Disabled state */
  disabled?: boolean;
}

export interface BadgeListProps {
  /** Array of badge items to render */
  items: BadgeListItem[];
  /** Size variant */
  size?: 'sm' | 'md' | 'lg';
  /** Allow multiple active selections */
  multiSelect?: boolean;
  /** Currently selected values */
  selectedValues?: string[];
  /** Callback when a badge is clicked */
  onItemClick?: (item: BadgeListItem) => void;
  /** Additional CSS classes */
  className?: string;
}

const colorMap: Record<BadgeColor, string> = {
  emerald: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  sky: 'bg-sky-50 text-sky-700 border-sky-200',
  amber: 'bg-amber-50 text-amber-700 border-amber-200',
  rose: 'bg-rose-50 text-rose-700 border-rose-200',
  violet: 'bg-violet-50 text-violet-700 border-violet-200',
  slate: 'bg-slate-100 text-slate-700 border-slate-200',
  primary: 'bg-slate-900 text-white border-slate-900',
};

const sizeMap = {
  sm: 'text-[10px] px-2 py-0.5',
  md: 'text-xs px-2.5 py-1',
  lg: 'text-sm px-3 py-1.5',
};

export function BadgeList({
  items,
  size = 'md',
  multiSelect = false,
  selectedValues = [],
  onItemClick,
  className,
}: BadgeListProps) {
  return (
    <div className={cn('flex flex-wrap gap-2', className)}>
      {items.map((item) => {
        const isSelected = selectedValues.includes(item.value);
        const baseClasses = cn(
          'inline-flex items-center rounded-full border font-medium transition-colors',
          sizeMap[size],
          colorMap[item.color],
          isSelected && 'ring-2 ring-offset-1 ring-slate-900',
          item.disabled && 'opacity-50 cursor-not-allowed',
          onItemClick && !item.disabled && 'cursor-pointer hover:brightness-95'
        );

        return (
          <button
            key={item.value}
            type="button"
            className={baseClasses}
            disabled={item.disabled}
            onClick={() => onItemClick?.(item)}
          >
            {item.label}
          </button>
        );
      })}
    </div>
  );
}
