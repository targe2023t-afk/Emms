/**
 * @component Timeline
 * @description Renders a vertical timeline of events with customizable
 *              icons, colors, and content. Supports both left and right
 *              aligned layouts.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <Timeline
 *   items={[
 *     { id: '1', title: 'Created', time: '2 hrs ago', status: 'completed' },
 *     { id: '2', title: 'In Progress', time: '1 hr ago', status: 'active' },
 *   ]}
 * />
 * ```
 */

import { cn } from '@/shared/lib/utils/cn';
import { CheckCircle2, Circle, Clock } from 'lucide-react';

export type TimelineStatus = 'completed' | 'active' | 'pending' | 'error';

export interface TimelineItem {
  /** Unique identifier */
  id: string;
  /** Event title */
  title: string;
  /** Optional subtitle or description */
  subtitle?: string;
  /** Timestamp text */
  time: string;
  /** Status for icon and color theming */
  status: TimelineStatus;
  /** Custom color override */
  color?: string;
}

export interface TimelineProps {
  /** Array of timeline events */
  items: TimelineItem[];
  /** Additional CSS classes */
  className?: string;
}

const statusConfig: Record<TimelineStatus, { icon: typeof Circle; color: string; bg: string }> = {
  completed: { icon: CheckCircle2, color: 'text-emerald-500', bg: 'bg-emerald-50' },
  active: { icon: Clock, color: 'text-sky-500', bg: 'bg-sky-50' },
  pending: { icon: Circle, color: 'text-slate-400', bg: 'bg-slate-100' },
  error: { icon: Circle, color: 'text-rose-500', bg: 'bg-rose-50' },
};

export function Timeline({ items, className }: TimelineProps) {
  return (
    <div className={cn('relative', className)}>
      {items.map((item, index) => {
        const config = statusConfig[item.status];
        const Icon = config.icon;
        const isLast = index === items.length - 1;

        return (
          <div key={item.id} className="relative flex gap-4 pb-6 last:pb-0">
            {/* Connector line */}
            {!isLast && (
              <div className="absolute left-[19px] top-8 bottom-0 w-px bg-slate-200" />
            )}
            {/* Icon */}
            <div className={cn('relative z-10 h-10 w-10 rounded-full flex items-center justify-center shrink-0', config.bg)}>
              <Icon className={cn('h-5 w-5', config.color)} />
            </div>
            {/* Content */}
            <div className="flex-1 pt-1.5">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-slate-900">{item.title}</h4>
                <span className="text-xs text-slate-400">{item.time}</span>
              </div>
              {item.subtitle && (
                <p className="text-xs text-slate-500 mt-0.5">{item.subtitle}</p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
