/**
 * @component StatCard
 * @description Generic statistic card displaying a value, label, trend indicator,
 *              and optional sparkline. Used for KPIs, metrics, and summary statistics.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <StatCard
 *   label="Total Revenue"
 *   value="$284,520"
 *   change="+8.4%"
 *   trend="up"
 *   icon={DollarSign}
 *   sparklineData={[30, 45, 38, 52, 48, 60, 55, 70]}
 * />
 * ```
 */

import { cn } from '@/shared/lib/utils/cn';
import { Card, CardContent } from '@/shared/ui/primitives/card';
import type { LucideIcon } from 'lucide-react';

export type TrendDirection = 'up' | 'down' | 'neutral';

export interface StatCardProps {
  /** Display label describing the metric */
  label: string;
  /** The primary value to display */
  value: string | number;
  /** Percentage or absolute change text */
  change?: string;
  /** Direction of the trend for color coding */
  trend?: TrendDirection;
  /** Lucide icon component for visual identification */
  icon?: LucideIcon;
  /** Tailwind color key for icon background theming */
  color?: 'emerald' | 'sky' | 'amber' | 'rose' | 'violet' | 'slate';
  /** Optional sparkline data points for mini chart */
  sparklineData?: number[];
  /** Additional CSS classes */
  className?: string;
  /** Click handler for interactivity */
  onClick?: () => void;
}

const colorMap = {
  emerald: 'bg-emerald-50 text-emerald-600',
  sky: 'bg-sky-50 text-sky-600',
  amber: 'bg-amber-50 text-amber-600',
  rose: 'bg-rose-50 text-rose-600',
  violet: 'bg-violet-50 text-violet-600',
  slate: 'bg-slate-50 text-slate-600',
};

const trendConfig = {
  up: { color: 'text-emerald-700 bg-emerald-50', icon: '↑' },
  down: { color: 'text-rose-700 bg-rose-50', icon: '↓' },
  neutral: { color: 'text-slate-600 bg-slate-100', icon: '→' },
};

/** Renders a simple SVG sparkline from data points */
const MiniSparkline = ({ data, color = '#64748b' }: { data: number[]; color?: string }) => {
  if (data.length < 2) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * 100;
    const y = 100 - ((v - min) / range) * 100;
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="h-8 w-full mt-2">
      <polyline
        fill="none"
        stroke={color}
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={points}
      />
    </svg>
  );
};

export function StatCard({
  label,
  value,
  change,
  trend = 'neutral',
  icon: Icon,
  color = 'slate',
  sparklineData,
  className,
  onClick,
}: StatCardProps) {
  const trendStyle = trendConfig[trend];

  return (
    <Card
      className={cn(
        'border-slate-200 shadow-sm transition-shadow hover:shadow-md',
        onClick && 'cursor-pointer',
        className
      )}
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          {Icon && (
            <div className={cn('rounded-lg p-2', colorMap[color])}>
              <Icon className="h-5 w-5" />
            </div>
          )}
          {change && (
            <span
              className={cn(
                'inline-flex items-center gap-0.5 rounded-full px-2 py-0.5 text-xs font-medium',
                trendStyle.color
              )}
            >
              {trendStyle.icon}
              {change}
            </span>
          )}
        </div>
        <div className="mt-3">
          <div className="text-2xl font-bold text-slate-900">{value}</div>
          <div className="text-xs text-slate-500">{label}</div>
        </div>
        {sparklineData && sparklineData.length > 0 && (
          <MiniSparkline data={sparklineData} />
        )}
      </CardContent>
    </Card>
  );
}
