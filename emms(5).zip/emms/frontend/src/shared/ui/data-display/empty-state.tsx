/**
 * @component EmptyState
 * @description Displays a consistent empty state message with icon, title,
 *              description, and optional action button. Used when no data
 *              is available for a view.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <EmptyState
 *   icon={Inbox}
 *   title="No work orders found"
 *   description="Get started by creating your first work order."
 *   action={{ label: 'Create Work Order', onClick: () => {} }}
 * />
 * ```
 */

import { cn } from '@/shared/lib/utils/cn';
import { Button } from '@/shared/ui/primitives/button';
import type { LucideIcon } from 'lucide-react';

export interface EmptyStateProps {
  /** Lucide icon component */
  icon: LucideIcon;
  /** Main title text */
  title: string;
  /** Descriptive helper text */
  description?: string;
  /** Optional action button configuration */
  action?: {
    label: string;
    onClick: () => void;
  };
  /** Compact variant for inline use */
  compact?: boolean;
  /** Additional CSS classes */
  className?: string;
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  compact = false,
  className,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center text-center',
        compact ? 'py-8' : 'py-16',
        className
      )}
    >
      <div
        className={cn(
          'rounded-full bg-slate-100 flex items-center justify-center',
          compact ? 'h-10 w-10 mb-3' : 'h-16 w-16 mb-4'
        )}
      >
        <Icon className={cn('text-slate-400', compact ? 'h-5 w-5' : 'h-8 w-8')} />
      </div>
      <h3
        className={cn(
          'font-semibold text-slate-900',
          compact ? 'text-sm' : 'text-base'
        )}
      >
        {title}
      </h3>
      {description && (
        <p className={cn('text-slate-500 mt-1', compact ? 'text-xs' : 'text-sm')}>{description}</p>
      )}
      {action && (
        <Button
          size={compact ? 'sm' : 'default'}
          className="mt-4"
          onClick={action.onClick}
        >
          {action.label}
        </Button>
      )}
    </div>
  );
}
