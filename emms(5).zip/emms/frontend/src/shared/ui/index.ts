/**
 * @fileoverview EMMS Shared UI Component Library
 * @description Enterprise-grade reusable UI components following SOLID principles.
 *              All components are generic, composable, and business-logic free.
 * @version 1.0.0
 * @author EMMS Design System
 */

// ─── Primitives (shadcn/ui base) ───
export { Button, buttonVariants } from './primitives/button';
export { Input } from './primitives/input';
export { Label } from './primitives/label';
export { Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent } from './primitives/card';
export { Avatar, AvatarImage, AvatarFallback } from './primitives/avatar';
export { Badge, badgeVariants } from './primitives/badge';
export { Separator } from './primitives/separator';
export { Skeleton } from './primitives/skeleton';
export * from './primitives/dropdown-menu';
export * from './primitives/toast';

// ─── Data Display ───
export { StatCard } from './data-display/stat-card';
export type { StatCardProps, TrendDirection } from './data-display/stat-card';
export { BadgeList } from './data-display/badge-list';
export type { BadgeListProps, BadgeListItem, BadgeColor } from './data-display/badge-list';
export { EmptyState } from './data-display/empty-state';
export type { EmptyStateProps } from './data-display/empty-state';
export { Timeline } from './data-display/timeline';
export type { TimelineProps, TimelineItem, TimelineStatus } from './data-display/timeline';

// ─── Feedback ───
export { Alert } from './feedback/alert';
export type { AlertProps, AlertVariant } from './feedback/alert';
export { ProgressBar } from './feedback/progress-bar';
export type { ProgressBarProps, ProgressSize, ProgressColor } from './feedback/progress-bar';
export { LoadingOverlay } from './feedback/loading-overlay';
export type { LoadingOverlayProps } from './feedback/loading-overlay';
export { StatusIndicator } from './feedback/status-indicator';
export type { StatusIndicatorProps, StatusType } from './feedback/status-indicator';

// ─── Forms ───
export { FormField } from './forms/form-field';
export type { FormFieldProps } from './forms/form-field';
export { SearchInput } from './forms/search-input';
export type { SearchInputProps } from './forms/search-input';
export { Select } from './forms/select';
export type { SelectProps, SelectOption } from './forms/select';
export { CheckboxGroup } from './forms/checkbox-group';
export type { CheckboxGroupProps, CheckboxOption } from './forms/checkbox-group';

// ─── Navigation ───
export { Breadcrumbs } from './navigation/breadcrumbs';
export type { BreadcrumbsProps, BreadcrumbItem } from './navigation/breadcrumbs';
export { Tabs } from './navigation/tabs';
export type { TabsProps, TabItem } from './navigation/tabs';
export { Pagination } from './navigation/pagination';
export type { PaginationProps } from './navigation/pagination';

// ─── Overlays ───
export { Modal, ModalBody, ModalFooter } from './overlays/modal';
export type { ModalProps } from './overlays/modal';
export { Drawer, DrawerHeader, DrawerBody } from './overlays/drawer';
export type { DrawerProps, DrawerPosition } from './overlays/drawer';
export { Tooltip } from './overlays/tooltip';
export type { TooltipProps, TooltipPosition } from './overlays/tooltip';

// ─── Layout ───
export { PageHeader } from './layout/page-header';
export type { PageHeaderProps, PageHeaderAction } from './layout/page-header';
export { SplitPane } from './layout/split-pane';
export type { SplitPaneProps, SplitOrientation } from './layout/split-pane';
export { ScrollContainer } from './layout/scroll-container';
export type { ScrollContainerProps } from './layout/scroll-container';

// ─── Tables ───
export { DataTable } from './tables/data-table';
export type { DataTableProps, DataTableColumn, SortDirection } from './tables/data-table';

// ─── Charts ───
export { BarChart } from './charts/bar-chart';
export type { BarChartProps, BarChartDataPoint } from './charts/bar-chart';

// ─── Composites ───
export { FilterPanel } from './composites/filter-panel';
export type { FilterPanelProps, FilterConfig, FilterType } from './composites/filter-panel';
export { ActionMenu } from './composites/action-menu';
export type { ActionMenuProps, ActionItem, ActionVariant } from './composites/action-menu';

// ─── Legacy / Composites ───
export { Toaster } from './toaster';
export { useToast, toast } from './use-toast';
export { LoadingScreen } from './loading-screen';
