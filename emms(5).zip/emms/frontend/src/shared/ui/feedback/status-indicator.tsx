/**
 * @component StatusIndicator
 * @description Compact status indicator with animated dot and label.
 *              Used for live status, availability, and state indicators.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <StatusIndicator status="active" label="Online" pulse />
 * ```
 */

import { cn } from '@/shared/lib/utils/cn';

export type StatusType = 'active' | 'idle' | 'offline' | 'warning' | 'error' | 'info';

export interface StatusIndicatorProps {
  /** Status type for color theming */
  status: StatusType;
  /** Optional label text */
  label?: string;
  /** Enable pulse animation */
  pulse?: boolean;
  /** Dot size */
  size?: 'sm' | 'md' | 'lg';
  /** Additional CSS classes */
  className?: string;
}

const statusConfig: Record<StatusType, { color: string; bg: string }> = {
  active: { color: 'bg-emerald-500', bg: 'bg-emerald-50' },
  idle: { color: 'bg-amber-400', bg: 'bg-amber-50' },
  offline: { color: 'bg-slate-400', bg: 'bg-slate-100' },
  warning: { color: 'bg-amber-500', bg: 'bg-amber-50' },
  error: { color: 'bg-rose-500', bg: 'bg-rose-50' },
  info: { color: 'bg-sky-500', bg: 'bg-sky-50' },
};

const sizeMap = {
  sm: 'h-1.5 w-1.5',
  md: 'h-2.5 w-2.5',
  lg: 'h-3.5 w-3.5',
};

export function StatusIndicator({
  status,
  label,
  pulse = false,
  size = 'md',
  className,
}: StatusIndicatorProps) {
  const config = statusConfig[status];

  return (
    <div className={cn('flex items-center gap-2', className)}>
      <span
        className={cn(
          'rounded-full',
          sizeMap[size],
          config.color,
          pulse && 'animate-pulse'
        )}
      />
      {label && (
        <span className="text-xs font-medium text-slate-600">{label}</span>
      )}
    </div>
  );
}
