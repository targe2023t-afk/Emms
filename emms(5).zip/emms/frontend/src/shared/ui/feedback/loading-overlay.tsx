/**
 * @component LoadingOverlay
 * @description Full or inline overlay with animated spinner. Blocks interaction
 *              when active. Supports custom messages and sizes.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <LoadingOverlay isLoading={isSubmitting} message="Saving changes..." />
 * ```
 */

import { cn } from '@/shared/lib/utils/cn';

export interface LoadingOverlayProps {
  /** Whether the overlay is visible */
  isLoading: boolean;
  /** Loading message text */
  message?: string;
  /** Overlay size: full screen or inline */
  fullScreen?: boolean;
  /** Spinner size */
  spinnerSize?: 'sm' | 'md' | 'lg';
  /** Background opacity */
  opacity?: 'light' | 'medium' | 'heavy';
  /** Additional CSS classes */
  className?: string;
  /** Children to render underneath overlay */
  children?: React.ReactNode;
}

const spinnerSizeMap = {
  sm: 'h-5 w-5 border-2',
  md: 'h-8 w-8 border-2',
  lg: 'h-12 w-12 border-3',
};

const opacityMap = {
  light: 'bg-white/40',
  medium: 'bg-white/70',
  heavy: 'bg-white/90',
};

export function LoadingOverlay({
  isLoading,
  message,
  fullScreen = false,
  spinnerSize = 'md',
  opacity = 'medium',
  className,
  children,
}: LoadingOverlayProps) {
  if (!isLoading && children) return <>{children}</>;
  if (!isLoading) return null;

  const overlay = (
    <div
      className={cn(
        'flex flex-col items-center justify-center z-50',
        fullScreen ? 'fixed inset-0' : 'absolute inset-0 rounded-lg',
        opacityMap[opacity],
        className
      )}
    >
      <div
        className={cn(
          'animate-spin rounded-full border-slate-900 border-t-transparent',
          spinnerSizeMap[spinnerSize]
        )}
      />
      {message && (
        <p className="mt-3 text-sm font-medium text-slate-600">{message}</p>
      )}
    </div>
  );

  if (fullScreen) return overlay;

  return (
    <div className="relative">
      {children}
      {overlay}
    </div>
  );
}
