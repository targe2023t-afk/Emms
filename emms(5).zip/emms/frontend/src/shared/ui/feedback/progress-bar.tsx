/**
 * @component ProgressBar
 * @description Visual progress indicator supporting linear and circular
 *              variants, multiple sizes, and color schemes. Fully accessible
 *              with ARIA progressbar role.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <ProgressBar value={72} max={100} size="md" color="emerald" showLabel />
 * ```
 */

import { cn } from '@/shared/lib/utils/cn';

export type ProgressSize = 'sm' | 'md' | 'lg';
export type ProgressColor = 'emerald' | 'sky' | 'amber' | 'rose' | 'violet' | 'slate' | 'primary';

export interface ProgressBarProps {
  /** Current value (0 to max) */
  value: number;
  /** Maximum value */
  max?: number;
  /** Visual size */
  size?: ProgressSize;
  /** Color scheme */
  color?: ProgressColor;
  /** Show percentage label */
  showLabel?: boolean;
  /** Label position */
  labelPosition?: 'inside' | 'outside' | 'none';
  /** Striped animated variant */
  striped?: boolean;
  /** Additional CSS classes */
  className?: string;
  /** Accessible label */
  ariaLabel?: string;
}

const sizeMap = {
  sm: 'h-1.5',
  md: 'h-2.5',
  lg: 'h-4',
};

const colorMap: Record<ProgressColor, string> = {
  emerald: 'bg-emerald-500',
  sky: 'bg-sky-500',
  amber: 'bg-amber-500',
  rose: 'bg-rose-500',
  violet: 'bg-violet-500',
  slate: 'bg-slate-500',
  primary: 'bg-slate-900',
};

export function ProgressBar({
  value,
  max = 100,
  size = 'md',
  color = 'primary',
  showLabel = false,
  labelPosition = 'outside',
  striped = false,
  className,
  ariaLabel,
}: ProgressBarProps) {
  const percentage = Math.min(100, Math.max(0, (value / max) * 100));

  return (
    <div className={cn('w-full', className)}>
      {(showLabel && labelPosition === 'outside') && (
        <div className="flex justify-between mb-1">
          <span className="text-xs text-slate-600">{ariaLabel}</span>
          <span className="text-xs font-medium text-slate-900">{Math.round(percentage)}%</span>
        </div>
      )}
      <div
        className={cn('w-full rounded-full bg-slate-200 overflow-hidden', sizeMap[size])}
        role="progressbar"
        aria-valuenow={value}
        aria-valuemin={0}
        aria-valuemax={max}
        aria-label={ariaLabel || 'Progress'}
      >
        <div
          className={cn(
            'h-full rounded-full transition-all duration-500 ease-out',
            colorMap[color],
            striped && 'bg-stripes animate-stripes'
          )}
          style={{ width: `${percentage}%` }}
        >
          {(showLabel && labelPosition === 'inside' && size !== 'sm') && (
            <span className="flex h-full items-center justify-center text-[10px] font-bold text-white">
              {Math.round(percentage)}%
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
