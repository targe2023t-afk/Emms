/**
 * @component Alert
 * @description Displays contextual feedback messages with severity levels.
 *              Supports icons, titles, descriptions, and action buttons.
 *              Follows ARIA alert roles for accessibility.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <Alert variant="error" title="Connection Failed">
 *   Unable to connect to the server. Please check your network.
 * </Alert>
 * ```
 */

import * as React from 'react';
import { cn } from '@/shared/lib/utils/cn';
import {
  AlertCircle,
  CheckCircle2,
  Info,
  TriangleAlert,
  X,
  type LucideIcon,
} from 'lucide-react';

export type AlertVariant = 'info' | 'success' | 'warning' | 'error';

export interface AlertProps {
  /** Severity level affecting color and icon */
  variant?: AlertVariant;
  /** Alert title */
  title?: string;
  /** Alert body content */
  children?: React.ReactNode;
  /** Dismissible with close button */
  dismissible?: boolean;
  /** Callback when dismissed */
  onDismiss?: () => void;
  /** Additional CSS classes */
  className?: string;
}

const variantConfig: Record<AlertVariant, { icon: LucideIcon; classes: string }> = {
  info: {
    icon: Info,
    classes: 'bg-sky-50 border-sky-200 text-sky-800',
  },
  success: {
    icon: CheckCircle2,
    classes: 'bg-emerald-50 border-emerald-200 text-emerald-800',
  },
  warning: {
    icon: TriangleAlert,
    classes: 'bg-amber-50 border-amber-200 text-amber-800',
  },
  error: {
    icon: AlertCircle,
    classes: 'bg-rose-50 border-rose-200 text-rose-800',
  },
};

export const Alert = React.forwardRef<HTMLDivElement, AlertProps>(
  ({ variant = 'info', title, children, dismissible, onDismiss, className }, ref) => {
    const config = variantConfig[variant];
    const Icon = config.icon;

    return (
      <div
        ref={ref}
        role="alert"
        className={cn(
          'relative rounded-lg border p-4',
          config.classes,
          className
        )}
      >
        <div className="flex gap-3">
          <Icon className="h-5 w-5 shrink-0 mt-0.5" />
          <div className="flex-1">
            {title && <h5 className="font-semibold text-sm">{title}</h5>}
            {children && <div className="text-sm mt-1 opacity-90">{children}</div>}
          </div>
          {dismissible && (
            <button
              onClick={onDismiss}
              className="shrink-0 rounded p-1 hover:bg-black/5 transition-colors"
              aria-label="Dismiss alert"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
    );
  }
);
Alert.displayName = 'Alert';
