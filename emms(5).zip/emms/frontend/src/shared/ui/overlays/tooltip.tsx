/**
 * @component Tooltip
 * @description Accessible tooltip that appears on hover/focus. Supports 12
 *              positions, custom content, and delay configuration.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <Tooltip content="Delete this item" position="top">
 *   <Button variant="destructive" size="icon">
 *     <Trash2 className="h-4 w-4" />
 *   </Button>
 * </Tooltip>
 * ```
 */

import * as React from 'react';
import { cn } from '@/shared/lib/utils/cn';

export type TooltipPosition =
  | 'top' | 'top-left' | 'top-right'
  | 'bottom' | 'bottom-left' | 'bottom-right'
  | 'left' | 'left-top' | 'left-bottom'
  | 'right' | 'right-top' | 'right-bottom';

export interface TooltipProps {
  /** Tooltip content (string or React node) */
  content: React.ReactNode;
  /** Position relative to trigger */
  position?: TooltipPosition;
  /** Delay before showing (ms) */
  delay?: number;
  /** Maximum width of tooltip */
  maxWidth?: number;
  /** Additional CSS classes */
  className?: string;
  /** Child element that triggers the tooltip */
  children: React.ReactElement;
}

const positionClasses: Record<TooltipPosition, string> = {
  'top': 'bottom-full left-1/2 -translate-x-1/2 mb-2',
  'top-left': 'bottom-full left-0 mb-2',
  'top-right': 'bottom-full right-0 mb-2',
  'bottom': 'top-full left-1/2 -translate-x-1/2 mt-2',
  'bottom-left': 'top-full left-0 mt-2',
  'bottom-right': 'top-full right-0 mt-2',
  'left': 'right-full top-1/2 -translate-y-1/2 mr-2',
  'left-top': 'right-full top-0 mr-2',
  'left-bottom': 'right-full bottom-0 mr-2',
  'right': 'left-full top-1/2 -translate-y-1/2 ml-2',
  'right-top': 'left-full top-0 ml-2',
  'right-bottom': 'left-full bottom-0 ml-2',
};

export function Tooltip({
  content,
  position = 'top',
  delay = 200,
  maxWidth = 250,
  className,
  children,
}: TooltipProps) {
  const [isVisible, setIsVisible] = React.useState(false);
  const timeoutRef = React.useRef<ReturnType<typeof setTimeout>>();

  const show = () => {
    clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => setIsVisible(true), delay);
  };

  const hide = () => {
    clearTimeout(timeoutRef.current);
    setIsVisible(false);
  };

  const child = React.Children.only(children);

  return (
    <div className="relative inline-flex">
      {React.cloneElement(child, {
        onMouseEnter: show,
        onMouseLeave: hide,
        onFocus: show,
        onBlur: hide,
      })}
      {isVisible && (
        <div
          className={cn(
            'absolute z-50 rounded-lg bg-slate-900 px-3 py-2 text-xs text-white shadow-lg',
            'animate-in fade-in zoom-in-95 duration-150',
            positionClasses[position],
            className
          )}
          style={{ maxWidth, width: 'max-content' }}
          role="tooltip"
        >
          {content}
        </div>
      )}
    </div>
  );
}
