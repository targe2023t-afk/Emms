/**
 * @component Drawer
 * @description Slide-out panel from any edge of the screen. Supports multiple
 *              sizes, backdrop overlay, and smooth animations.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <Drawer isOpen={isOpen} onClose={() => setIsOpen(false)} position="right" size="md">
 *   <DrawerHeader>Filters</DrawerHeader>
 *   <DrawerBody>Filter content here</DrawerBody>
 * </Drawer>
 * ```
 */

import * as React from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { cn } from '@/shared/lib/utils/cn';

export type DrawerPosition = 'left' | 'right' | 'top' | 'bottom';

export interface DrawerProps {
  /** Whether the drawer is visible */
  isOpen: boolean;
  /** Close handler */
  onClose: () => void;
  /** Slide direction */
  position?: DrawerPosition;
  /** Drawer size (width for left/right, height for top/bottom) */
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  /** Prevent backdrop click close */
  preventBackdropClose?: boolean;
  /** Additional CSS classes */
  className?: string;
  /** Drawer content */
  children: React.ReactNode;
}

const sizeMap = {
  sm: 'w-72 h-72',
  md: 'w-96 h-96',
  lg: 'w-[32rem] h-[32rem]',
  xl: 'w-[40rem] h-[40rem]',
  full: 'w-full h-full',
};

const positionClasses: Record<DrawerPosition, string> = {
  left: 'left-0 top-0 h-full',
  right: 'right-0 top-0 h-full',
  top: 'top-0 left-0 w-full',
  bottom: 'bottom-0 left-0 w-full',
};

const animationClasses: Record<DrawerPosition, string> = {
  left: 'animate-in slide-in-from-left duration-300',
  right: 'animate-in slide-in-from-right duration-300',
  top: 'animate-in slide-in-from-top duration-300',
  bottom: 'animate-in slide-in-from-bottom duration-300',
};

export function Drawer({
  isOpen,
  onClose,
  position = 'right',
  size = 'md',
  preventBackdropClose = false,
  className,
  children,
}: DrawerProps) {
  const overlayRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      const handleEscape = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
      };
      document.addEventListener('keydown', handleEscape);
      return () => {
        document.body.style.overflow = '';
        document.removeEventListener('keydown', handleEscape);
      };
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === overlayRef.current && !preventBackdropClose) {
      onClose();
    }
  };

  const drawer = (
    <div
      ref={overlayRef}
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={handleBackdropClick}
    >
      <div
        className={cn(
          'absolute bg-white shadow-2xl overflow-auto',
          positionClasses[position],
          sizeMap[size],
          animationClasses[position],
          className
        )}
        role="dialog"
        aria-modal="true"
      >
        {children}
      </div>
    </div>
  );

  return createPortal(drawer, document.body);
}

/** Drawer header with title and close button */
export function DrawerHeader({
  title,
  onClose,
  className,
}: {
  title?: string;
  onClose?: () => void;
  className?: string;
}) {
  return (
    <div className={cn('flex items-center justify-between px-6 py-4 border-b border-slate-100', className)}>
      {title && <h2 className="text-lg font-semibold text-slate-900">{title}</h2>}
      {onClose && (
        <button
          onClick={onClose}
          className="rounded-lg p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          aria-label="Close drawer"
        >
          <X className="h-5 w-5" />
        </button>
      )}
    </div>
  );
}

/** Drawer body content wrapper */
export function DrawerBody({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return <div className={cn('px-6 py-4', className)}>{children}</div>;
}
