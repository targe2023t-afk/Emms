/**
 * @component Pagination
 * @description Accessible pagination controls with previous/next buttons,
 *              page number display, ellipsis truncation, and page size selector.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <Pagination
 *   pageIndex={0}
 *   pageSize={20}
 *   totalCount={156}
 *   onPageChange={(page) => setPage(page)}
 *   onPageSizeChange={(size) => setPageSize(size)}
 * />
 * ```
 */

import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/shared/lib/utils/cn';
import { Button } from '@/shared/ui/primitives/button';

export interface PaginationProps {
  /** Current page index (0-based) */
  pageIndex: number;
  /** Items per page */
  pageSize: number;
  /** Total item count */
  totalCount: number;
  /** Available page sizes */
  pageSizeOptions?: number[];
  /** Page change callback */
  onPageChange: (pageIndex: number) => void;
  /** Page size change callback */
  onPageSizeChange?: (pageSize: number) => void;
  /** Maximum visible page buttons */
  siblingCount?: number;
  /** Additional CSS classes */
  className?: string;
}

export function Pagination({
  pageIndex,
  pageSize,
  totalCount,
  pageSizeOptions = [10, 20, 50, 100],
  onPageChange,
  onPageSizeChange,
  siblingCount = 1,
  className,
}: PaginationProps) {
  const totalPages = Math.ceil(totalCount / pageSize);
  const startItem = pageIndex * pageSize + 1;
  const endItem = Math.min((pageIndex + 1) * pageSize, totalCount);

  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    const leftSibling = Math.max(0, pageIndex - siblingCount);
    const rightSibling = Math.min(totalPages - 1, pageIndex + siblingCount);

    if (leftSibling > 1) pages.push(1);
    if (leftSibling > 2) pages.push('...');

    for (let i = leftSibling; i <= rightSibling; i++) {
      pages.push(i + 1);
    }

    if (rightSibling < totalPages - 2) pages.push('...');
    if (rightSibling < totalPages - 1) pages.push(totalPages);

    return pages;
  };

  return (
    <div className={cn('flex flex-col sm:flex-row items-center justify-between gap-4', className)}>
      <div className="text-sm text-slate-500">
        Showing <span className="font-medium text-slate-900">{startItem}</span> to{' '}
        <span className="font-medium text-slate-900">{endItem}</span> of{' '}
        <span className="font-medium text-slate-900">{totalCount}</span> results
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          className="h-8 w-8 p-0"
          onClick={() => onPageChange(pageIndex - 1)}
          disabled={pageIndex === 0}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        <div className="flex items-center gap-1">
          {getPageNumbers().map((page, i) =>
            typeof page === 'string' ? (
              <span key={`ellipsis-${i}`} className="px-2 text-sm text-slate-400">
                ...
              </span>
            ) : (
              <Button
                key={page}
                variant={page === pageIndex + 1 ? 'default' : 'outline'}
                size="sm"
                className={cn(
                  'h-8 w-8 p-0 text-xs',
                  page === pageIndex + 1 && 'bg-slate-900'
                )}
                onClick={() => onPageChange(page - 1)}
              >
                {page}
              </Button>
            )
          )}
        </div>

        <Button
          variant="outline"
          size="sm"
          className="h-8 w-8 p-0"
          onClick={() => onPageChange(pageIndex + 1)}
          disabled={pageIndex >= totalPages - 1}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {onPageSizeChange && (
        <select
          value={pageSize}
          onChange={(e) => onPageSizeChange(Number(e.target.value))}
          className="h-8 rounded-lg border border-slate-200 bg-white px-2 text-xs focus:outline-none focus:ring-2 focus:ring-slate-900"
        >
          {pageSizeOptions.map((size) => (
            <option key={size} value={size}>
              {size} / page
            </option>
          ))}
        </select>
      )}
    </div>
  );
}
