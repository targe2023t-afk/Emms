/**
 * @component Breadcrumbs
 * @description Hierarchical navigation showing the current page path.
 *              Supports custom separators, click handlers, and max item limits.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <Breadcrumbs
 *   items={[
 *     { label: 'Home', href: '/' },
 *     { label: 'Work Orders', href: '/wo' },
 *     { label: 'WO-2841', href: '/wo/2841', active: true },
 *   ]}
 * />
 * ```
 */

import * as React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';
import { cn } from '@/shared/lib/utils/cn';

export interface BreadcrumbItem {
  /** Display label */
  label: string;
  /** Navigation href (optional for last item) */
  href?: string;
  /** Current active item */
  active?: boolean;
  /** Icon component */
  icon?: typeof Home;
}

export interface BreadcrumbsProps {
  /** Array of breadcrumb segments */
  items: BreadcrumbItem[];
  /** Custom separator element */
  separator?: React.ReactNode;
  /** Maximum items before collapsing (shows first + last + ellipsis) */
  maxItems?: number;
  /** Additional CSS classes */
  className?: string;
  /** Click handler for non-link items */
  onItemClick?: (item: BreadcrumbItem) => void;
}

export function Breadcrumbs({
  items,
  separator = <ChevronRight className="h-3.5 w-3.5 text-slate-400" />,
  maxItems = 5,
  className,
  onItemClick,
}: BreadcrumbsProps) {
  const displayItems = React.useMemo(() => {
    if (items.length <= maxItems) return items;
    return [
      items[0],
      { label: '...', href: undefined },
      ...items.slice(-2),
    ];
  }, [items, maxItems]);

  return (
    <nav aria-label="Breadcrumb" className={cn(className)}>
      <ol className="flex flex-wrap items-center gap-1.5">
        {displayItems.map((item, index) => {
          const isLast = index === displayItems.length - 1;

          return (
            <li key={`${item.label}-${index}`} className="flex items-center gap-1.5">
              {index > 0 && <span className="mx-0.5">{separator}</span>}
              {item.href && !isLast ? (
                <Link
                  to={item.href}
                  className="text-sm text-slate-500 hover:text-slate-900 transition-colors"
                  onClick={() => onItemClick?.(item)}
                >
                  {item.icon && <item.icon className="h-3.5 w-3.5 inline mr-1" />}
                  {item.label}
                </Link>
              ) : (
                <span
                  className={cn(
                    'text-sm',
                    isLast ? 'font-medium text-slate-900' : 'text-slate-500'
                  )}
                  aria-current={isLast ? 'page' : undefined}
                >
                  {item.icon && <item.icon className="h-3.5 w-3.5 inline mr-1" />}
                  {item.label}
                </span>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
