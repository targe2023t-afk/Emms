/**
 * @component Tabs
 * @description Accessible tab navigation with keyboard support, animated
 *              indicator, and multiple variants. Follows WAI-ARIA tab pattern.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <Tabs
 *   tabs={[
 *     { id: 'all', label: 'All' },
 *     { id: 'active', label: 'Active', badge: 12 },
 *   ]}
 *   activeTab={activeTab}
 *   onTabChange={setActiveTab}
 * />
 * ```
 */

import * as React from 'react';
import { cn } from '@/shared/lib/utils/cn';

export interface TabItem {
  /** Unique tab identifier */
  id: string;
  /** Display label */
  label: string;
  /** Optional badge count */
  badge?: number | string;
  /** Disabled state */
  disabled?: boolean;
  /** Icon component */
  icon?: React.ComponentType<{ className?: string }>;
}

export interface TabsProps {
  /** Array of tab definitions */
  tabs: TabItem[];
  /** Currently active tab ID */
  activeTab: string;
  /** Tab change handler */
  onTabChange: (tabId: string) => void;
  /** Visual variant */
  variant?: 'default' | 'pills' | 'underline';
  /** Size variant */
  size?: 'sm' | 'md' | 'lg';
  /** Full width tabs */
  fullWidth?: boolean;
  /** Additional CSS classes */
  className?: string;
}

const variantMap = {
  default: {
    container: 'bg-slate-100 rounded-lg p-1',
    tab: 'rounded-md px-3 py-1.5 text-sm font-medium transition-all',
    active: 'bg-white text-slate-900 shadow-sm',
    inactive: 'text-slate-500 hover:text-slate-700',
  },
  pills: {
    container: 'border-b border-slate-200',
    tab: 'px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-all',
    active: 'border-slate-900 text-slate-900',
    inactive: 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300',
  },
  underline: {
    container: 'border-b border-slate-200 gap-6',
    tab: 'pb-2.5 text-sm font-medium border-b-2 -mb-px transition-all',
    active: 'border-sky-500 text-sky-600',
    inactive: 'border-transparent text-slate-500 hover:text-slate-700',
  },
};

export function Tabs({
  tabs,
  activeTab,
  onTabChange,
  variant = 'default',
  size = 'md',
  fullWidth = false,
  className,
}: TabsProps) {
  const config = variantMap[variant];

  return (
    <div
      className={cn('flex', config.container, fullWidth && 'w-full', className)}
      role="tablist"
    >
      {tabs.map((tab) => {
        const isActive = tab.id === activeTab;
        const Icon = tab.icon;

        return (
          <button
            key={tab.id}
            role="tab"
            aria-selected={isActive}
            aria-disabled={tab.disabled}
            disabled={tab.disabled}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              'flex items-center justify-center gap-2 whitespace-nowrap',
              fullWidth && 'flex-1',
              config.tab,
              isActive ? config.active : config.inactive,
              tab.disabled && 'opacity-40 cursor-not-allowed'
            )}
          >
            {Icon && <Icon className="h-4 w-4" />}
            {tab.label}
            {tab.badge !== undefined && (
              <span
                className={cn(
                  'rounded-full px-1.5 py-0.5 text-[10px] font-bold',
                  isActive ? 'bg-slate-900/10 text-slate-900' : 'bg-slate-200 text-slate-600'
                )}
              >
                {tab.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
