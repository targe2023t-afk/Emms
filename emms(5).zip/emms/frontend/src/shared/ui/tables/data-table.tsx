/**
 * @component DataTable
 * @description Generic data table with column sorting, row selection, pagination
 *              integration, and action column support. Headless design allows
 *              any data shape via column definitions.
 * @author EMMS Design System
 * @since 1.0.0
 *
 * @example
 * ```tsx
 * <DataTable
 *   data={workOrders}
 *   columns={[
 *     { key: 'number', header: 'WO #', sortable: true },
 *     { key: 'asset', header: 'Asset', render: (row) => <span>{row.asset}</span> },
 *     { key: 'status', header: 'Status', render: (row) => <StatusBadge status={row.status} /> },
 *   ]}
 *   selectable
 *   onRowClick={(row) => navigate(`/wo/${row.id}`)}
 * />
 * ```
 */

import * as React from 'react';
import { ChevronUp, ChevronDown, GripVertical } from 'lucide-react';
import { cn } from '@/shared/lib/utils/cn';
import { Checkbox } from '@/shared/ui/forms/checkbox-group';

export type SortDirection = 'asc' | 'desc' | null;

export interface DataTableColumn<T> {
  /** Unique column key */
  key: string;
  /** Column header text */
  header: string;
  /** Enable sorting on this column */
  sortable?: boolean;
  /** Custom cell renderer */
  render?: (row: T, index: number) => React.ReactNode;
  /** Column width */
  width?: string;
  /** Column alignment */
  align?: 'left' | 'center' | 'right';
  /** Hide on mobile */
  hideOnMobile?: boolean;
}

export interface DataTableProps<T> {
  /** Data array */
  data: T[];
  /** Column definitions */
  columns: DataTableColumn<T>[];
  /** Enable row selection */
  selectable?: boolean;
  /** Selected row IDs */
  selectedIds?: string[];
  /** Row ID accessor (defaults to 'id') */
  idKey?: keyof T;
  /** Selection change handler */
  onSelectionChange?: (ids: string[]) => void;
  /** Row click handler */
  onRowClick?: (row: T) => void;
  /** Sort change handler */
  onSort?: (column: string, direction: SortDirection) => void;
  /** Current sort state */
  sortColumn?: string;
  sortDirection?: SortDirection;
  /** Loading state */
  loading?: boolean;
  /** Empty state message */
  emptyMessage?: string;
  /** Additional CSS classes */
  className?: string;
  /** Row className accessor */
  rowClassName?: (row: T, index: number) => string;
  /** Sticky header */
  stickyHeader?: boolean;
}

export function DataTable<T extends Record<string, any>>({
  data,
  columns,
  selectable,
  selectedIds = [],
  idKey = 'id',
  onSelectionChange,
  onRowClick,
  onSort,
  sortColumn,
  sortDirection,
  loading,
  emptyMessage = 'No data available',
  className,
  rowClassName,
  stickyHeader = false,
}: DataTableProps<T>) {
  const allSelected = data.length > 0 && data.every((row) => selectedIds.includes(String(row[idKey])));
  const someSelected = data.some((row) => selectedIds.includes(String(row[idKey]))) && !allSelected;

  const toggleAll = () => {
    if (!onSelectionChange) return;
    if (allSelected) {
      onSelectionChange(selectedIds.filter((id) => !data.some((row) => String(row[idKey]) === id)));
    } else {
      const newIds = data.map((row) => String(row[idKey]));
      onSelectionChange([...new Set([...selectedIds, ...newIds])]);
    }
  };

  const toggleRow = (id: string) => {
    if (!onSelectionChange) return;
    if (selectedIds.includes(id)) {
      onSelectionChange(selectedIds.filter((sid) => sid !== id));
    } else {
      onSelectionChange([...selectedIds, id]);
    }
  };

  const handleSort = (column: DataTableColumn<T>) => {
    if (!column.sortable || !onSort) return;
    const newDirection: SortDirection =
      sortColumn === column.key && sortDirection === 'asc' ? 'desc' : 'asc';
    onSort(column.key, newDirection);
  };

  const alignMap = {
    left: 'text-left',
    center: 'text-center',
    right: 'text-right',
  };

  return (
    <div className={cn('overflow-x-auto', className)}>
      <table className="w-full min-w-[640px]">
        <thead className={cn(stickyHeader && 'sticky top-0 z-10')}>
          <tr className="border-b border-slate-100 bg-slate-50/50">
            {selectable && (
              <th className="pb-3 pl-4 pr-2 text-left w-10">
                <div
                  className={cn(
                    'h-4 w-4 rounded border flex items-center justify-center cursor-pointer transition-colors',
                    allSelected ? 'bg-slate-900 border-slate-900' : 'border-slate-300 bg-white',
                    someSelected && 'bg-slate-900/50 border-slate-900'
                  )}
                  onClick={toggleAll}
                >
                  {(allSelected || someSelected) && (
                    <svg className="h-3 w-3 text-white" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <path d="M2 6l3 3 5-5" />
                    </svg>
                  )}
                </div>
              </th>
            )}
            {columns.map((column) => (
              <th
                key={column.key}
                className={cn(
                  'pb-3 text-left text-[11px] font-semibold uppercase tracking-wider text-slate-400',
                  column.align && alignMap[column.align],
                  column.hideOnMobile && 'hidden md:table-cell',
                  column.sortable && 'cursor-pointer select-none hover:text-slate-600'
                )}
                style={{ width: column.width }}
                onClick={() => handleSort(column)}
              >
                <div className={cn('flex items-center gap-1', column.align === 'right' && 'justify-end')}>
                  {column.header}
                  {column.sortable && sortColumn === column.key && (
                    sortDirection === 'asc' ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />
                  )}
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="text-sm">
          {loading ? (
            <tr>
              <td colSpan={columns.length + (selectable ? 1 : 0)} className="py-8 text-center text-slate-400">
                Loading...
              </td>
            </tr>
          ) : data.length === 0 ? (
            <tr>
              <td colSpan={columns.length + (selectable ? 1 : 0)} className="py-8 text-center text-slate-400">
                {emptyMessage}
              </td>
            </tr>
          ) : (
            data.map((row, index) => {
              const rowId = String(row[idKey]);
              const isSelected = selectedIds.includes(rowId);

              return (
                <tr
                  key={rowId}
                  className={cn(
                    'border-b border-slate-50 transition-colors',
                    onRowClick && 'cursor-pointer hover:bg-slate-50/50',
                    isSelected && 'bg-slate-50',
                    rowClassName?.(row, index)
                  )}
                  onClick={() => onRowClick?.(row)}
                >
                  {selectable && (
                    <td className="py-3 pl-4 pr-2" onClick={(e) => e.stopPropagation()}>
                      <div
                        className={cn(
                          'h-4 w-4 rounded border flex items-center justify-center cursor-pointer transition-colors',
                          isSelected ? 'bg-slate-900 border-slate-900' : 'border-slate-300 bg-white'
                        )}
                        onClick={() => toggleRow(rowId)}
                      >
                        {isSelected && (
                          <svg className="h-3 w-3 text-white" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2.5">
                            <path d="M2 6l3 3 5-5" />
                          </svg>
                        )}
                      </div>
                    </td>
                  )}
                  {columns.map((column) => (
                    <td
                      key={column.key}
                      className={cn(
                        'py-3',
                        column.align && alignMap[column.align],
                        column.hideOnMobile && 'hidden md:table-cell'
                      )}
                    >
                      {column.render
                        ? column.render(row, index)
                        : String(row[column.key] ?? '')}
                    </td>
                  ))}
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
}
