import { format, parseISO } from 'date-fns';
import { APP_CONFIG } from '@/shared/config/app.config';

export function formatDate(date: string | Date, formatStr?: string): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return format(d, formatStr || APP_CONFIG.dateFormat);
}

export function formatDateTime(date: string | Date): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return format(d, APP_CONFIG.dateTimeFormat);
}
