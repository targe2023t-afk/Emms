import { Outlet } from 'react-router-dom';
import { Header } from '@/widgets/layout/ui/header';
import { Sidebar } from '@/widgets/layout/ui/sidebar';
import { useAuthStore } from '@/features/auth/model';

export function RootLayout() {
  const { isAuthenticated } = useAuthStore();

  return (
    <div className="min-h-screen bg-background">
      {isAuthenticated && <Header />}
      <div className="flex">
        {isAuthenticated && <Sidebar />}
        <main className="flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
